package com.example.exam;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class ActivityExpense extends AppCompatActivity {

    private EditText nameEditText, categoryEditText, amountEditText, dateEditText;
    private Button saveExpenseButton;
    private ListView expenseListView;

    private ArrayList<String> expenseList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);

        nameEditText = findViewById(R.id.name);
        categoryEditText = findViewById(R.id.categoryEditText);
        amountEditText = findViewById(R.id.amountEditText);
        dateEditText = findViewById(R.id.dateEditText);
        saveExpenseButton = findViewById(R.id.saveExpenseButton);
        expenseListView = findViewById(R.id.expenseListView);

        expenseList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expenseList);
        expenseListView.setAdapter(adapter);

        saveExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveExpense();
            }
        });
    }

    private void saveExpense() {
        String name = nameEditText.getText().toString().trim();
        String category = categoryEditText.getText().toString().trim();
        String amountString = amountEditText.getText().toString().trim();
        String date = dateEditText.getText().toString().trim();

        // Validate inputs
        if (name.isEmpty() || category.isEmpty() || amountString.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "All fields must be filled", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate amount
        double amount;
        try {
            amount = Double.parseDouble(amountString);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Amount must be a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate date
        if (!isValidDate(date)) {
            Toast.makeText(this, "Date cannot be in the future", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add expense to the list and update the adapter
        String expense = "Name: " + name + ", Category: " + category + ", Amount: " + amount + ", Date: " + date;
        expenseList.add(expense);
        adapter.notifyDataSetChanged(); // Notify adapter about data change

        // Clear input fields
        clearFields();
    }

    private boolean isValidDate(String date) {
        // Check if the date is in the format YYYY-MM-DD
        String[] parts = date.split("-");
        if (parts.length != 3) return false;

        try {
            int year = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]) - 1;
            int day = Integer.parseInt(parts[2]);

            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, day);
            return !calendar.after(Calendar.getInstance());
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void clearFields() {
        nameEditText.setText("");
        categoryEditText.setText("");
        amountEditText.setText("");
        dateEditText.setText("");
    }
}
