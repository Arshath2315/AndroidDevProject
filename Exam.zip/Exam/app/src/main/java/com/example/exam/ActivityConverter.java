package com.example.exam;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ActivityConverter extends AppCompatActivity {

    EditText feetEditText;
    EditText inchEditText;
    Button convertButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_converter);

        feetEditText = findViewById(R.id.feetEditText);
        inchEditText = findViewById(R.id.inchEditText);
        convertButton = findViewById(R.id.convertButton);
        resultTextView = findViewById(R.id.resultTextView);

        convertButton.setOnClickListener(v -> {
            // Check for empty input fields
            if (feetEditText.getText().toString().isEmpty() && inchEditText.getText().toString().isEmpty()) {
                resultTextView.setText("Please enter feet and/or inches.");
                return;
            }

            double feet = 0;
            double inches = 0;

            // Validator
            if (!feetEditText.getText().toString().isEmpty()) {
                feet = Double.parseDouble(feetEditText.getText().toString());
            }
            if (!inchEditText.getText().toString().isEmpty()) {
                inches = Double.parseDouble(inchEditText.getText().toString());
            }

            // Calculate total inches
            double totalInches = (feet * 12) + inches;

            // Convert inches to centimeters
            double centimetersFromInches = totalInches * 2.54;

            // Convert feet to centimeters
            double centimetersFromFeet = feet * 30.48;

            // Display
            resultTextView.setText("Inches to Centimeters: " + centimetersFromInches + "\n" +
                    "Feet to Centimeters: " + centimetersFromFeet);
        });
    }
}
